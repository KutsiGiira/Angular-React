import React, { useState } from 'react';

export const NotifiedForm: React.FC = () => {
  return (
    <>
      
    </>
  );
};

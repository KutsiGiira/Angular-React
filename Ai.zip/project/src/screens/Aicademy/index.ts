export { Aicademy } from "./Aicademy";

import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { User, Lock, ArrowRight } from 'lucide-react';
import FormInput from '../components/FormInput';
import { Button } from '../components/ui/Button';
import AuthLayout from '../layouts/AuthLayout';

const Login = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    username: '',
    password: ''
  });
  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
    
    // Clear error when user starts typing
    if (errors[name]) {
      setErrors({
        ...errors,
        [name]: ''
      });
    }
  };

  const validate = () => {
    const newErrors = {};
    
    if (!formData.username.trim()) {
      newErrors.username = 'Username or phone number is required';
    }
    
    if (!formData.password) {
      newErrors.password = 'Password is required';
    } else if (formData.password.length < 6) {
      newErrors.password = 'Password must be at least 6 characters';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (validate()) {
      setIsSubmitting(true);
      
      // Simulate API call
      setTimeout(() => {
        console.log('Login attempt with:', formData);
        setIsSubmitting(false);
        // Handle successful login here
      }, 1500);
    }
  };

  const goToResetPassword = () => {
    navigate('/reset-password');
  };

  return (
    <AuthLayout title="Welcome back">
      <form onSubmit={handleSubmit} className="w-full space-y-6">
        <FormInput
          name="username"
          label="Username or Phone Number"
          value={formData.username}
          onChange={handleChange}
          error={errors.username}
          icon={<User size={18} className="text-gray-400" />}
          placeholder="Enter your username or phone"
          autoComplete="username"
        />
        
        <div className="space-y-1">
          <FormInput
            name="password"
            type="password"
            label="Password"
            value={formData.password}
            onChange={handleChange}
            error={errors.password}
            icon={<Lock size={18} className="text-gray-400" />}
            placeholder="Enter your password"
            autoComplete="current-password"
          />
          
          <button
            type="button"
            onClick={goToResetPassword}
            className="text-sm text-blue-600 hover:text-blue-800 transition-colors duration-200 hover:underline focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 rounded"
          >
            Forgot password?
          </button>
        </div>
        
        <Button
          type="submit"
          disabled={isSubmitting}
          className="w-full flex items-center justify-center gap-2"
        >
          {isSubmitting ? (
            <span className="flex items-center gap-2">
              <svg className="animate-spin h-4 w-4 text-white\" xmlns="http://www.w3.org/2000/svg\" fill="none\" viewBox="0 0 24 24">
                <circle className="opacity-25\" cx="12\" cy="12\" r="10\" stroke="currentColor\" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              Signing in...
            </span>
          ) : (
            <>
              Sign in
              <ArrowRight size={18} />
            </>
          )}
        </Button>
      </form>
    </AuthLayout>
  );
};

export default Login;
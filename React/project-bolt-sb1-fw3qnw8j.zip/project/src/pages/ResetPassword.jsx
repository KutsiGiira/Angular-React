import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { AtSign, KeyRound, ArrowLeft, Check } from 'lucide-react';
import FormInput from '../components/FormInput';
import { Button } from '../components/ui/Button';
import AuthLayout from '../layouts/AuthLayout';

const ResetPassword = () => {
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    email: '',
    code: '',
    newPassword: '',
    confirmPassword: ''
  });
  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
    
    // Clear error when user starts typing
    if (errors[name]) {
      setErrors({
        ...errors,
        [name]: ''
      });
    }
  };

  const validateStep1 = () => {
    const newErrors = {};
    
    if (!formData.email.trim()) {
      newErrors.email = 'Email is required';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = 'Email address is invalid';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const validateStep2 = () => {
    const newErrors = {};
    
    if (!formData.code.trim()) {
      newErrors.code = 'Verification code is required';
    } else if (formData.code.length !== 6) {
      newErrors.code = 'Code must be 6 digits';
    }
    
    if (!formData.newPassword) {
      newErrors.newPassword = 'New password is required';
    } else if (formData.newPassword.length < 8) {
      newErrors.newPassword = 'Password must be at least 8 characters';
    }
    
    if (!formData.confirmPassword) {
      newErrors.confirmPassword = 'Please confirm your password';
    } else if (formData.newPassword !== formData.confirmPassword) {
      newErrors.confirmPassword = 'Passwords do not match';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmitStep1 = (e) => {
    e.preventDefault();
    
    if (validateStep1()) {
      setIsSubmitting(true);
      
      // Simulate API call to send reset email
      setTimeout(() => {
        console.log('Reset password request for:', formData.email);
        setIsSubmitting(false);
        setStep(2);
      }, 1500);
    }
  };

  const handleSubmitStep2 = (e) => {
    e.preventDefault();
    
    if (validateStep2()) {
      setIsSubmitting(true);
      
      // Simulate API call to verify code and set new password
      setTimeout(() => {
        console.log('New password set with verification code:', formData.code);
        setIsSubmitting(false);
        setStep(3);
      }, 1500);
    }
  };

  const goToLogin = () => {
    navigate('/login');
  };

  // Step 1: Request password reset
  if (step === 1) {
    return (
      <AuthLayout title="Reset your password">
        <p className="text-gray-600 text-sm mb-6">
          Enter your email address and we'll send you a verification code to reset your password.
        </p>
        
        <form onSubmit={handleSubmitStep1} className="w-full space-y-6">
          <FormInput
            name="email"
            label="Email Address"
            value={formData.email}
            onChange={handleChange}
            error={errors.email}
            icon={<AtSign size={18} className="text-gray-400" />}
            placeholder="Enter your email address"
            autoComplete="email"
          />
          
          <div className="flex items-center gap-4">
            <Button
              type="button"
              variant="outline"
              onClick={goToLogin}
              className="flex-1 flex items-center justify-center gap-2"
            >
              <ArrowLeft size={18} />
              Back to Login
            </Button>
            
            <Button
              type="submit"
              disabled={isSubmitting}
              className="flex-1 flex items-center justify-center gap-2"
            >
              {isSubmitting ? (
                <span className="flex items-center gap-2">
                  <svg className="animate-spin h-4 w-4 text-white\" xmlns="http://www.w3.org/2000/svg\" fill="none\" viewBox="0 0 24 24">
                    <circle className="opacity-25\" cx="12\" cy="12\" r="10\" stroke="currentColor\" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  Sending...
                </span>
              ) : (
                'Send Code'
              )}
            </Button>
          </div>
        </form>
      </AuthLayout>
    );
  }
  
  // Step 2: Enter verification code and new password
  if (step === 2) {
    return (
      <AuthLayout title="Create new password">
        <p className="text-gray-600 text-sm mb-6">
          Enter the verification code sent to <span className="font-medium">{formData.email}</span> and create your new password.
        </p>
        
        <form onSubmit={handleSubmitStep2} className="w-full space-y-6">
          <FormInput
            name="code"
            label="Verification Code"
            value={formData.code}
            onChange={handleChange}
            error={errors.code}
            placeholder="Enter 6-digit code"
            maxLength={6}
            className="tracking-wider text-center"
          />
          
          <FormInput
            name="newPassword"
            type="password"
            label="New Password"
            value={formData.newPassword}
            onChange={handleChange}
            error={errors.newPassword}
            icon={<KeyRound size={18} className="text-gray-400" />}
            placeholder="Create new password"
            autoComplete="new-password"
          />
          
          <FormInput
            name="confirmPassword"
            type="password"
            label="Confirm Password"
            value={formData.confirmPassword}
            onChange={handleChange}
            error={errors.confirmPassword}
            icon={<KeyRound size={18} className="text-gray-400" />}
            placeholder="Confirm new password"
            autoComplete="new-password"
          />
          
          <Button
            type="submit"
            disabled={isSubmitting}
            className="w-full flex items-center justify-center gap-2"
          >
            {isSubmitting ? (
              <span className="flex items-center gap-2">
                <svg className="animate-spin h-4 w-4 text-white\" xmlns="http://www.w3.org/2000/svg\" fill="none\" viewBox="0 0 24 24">
                  <circle className="opacity-25\" cx="12\" cy="12\" r="10\" stroke="currentColor\" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Updating...
              </span>
            ) : (
              'Reset Password'
            )}
          </Button>
        </form>
      </AuthLayout>
    );
  }
  
  // Step 3: Success
  return (
    <AuthLayout title="Password reset successful">
      <div className="flex flex-col items-center text-center">
        <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-4">
          <Check size={28} className="text-green-600" />
        </div>
        
        <p className="text-gray-600 mb-8">
          Your password has been successfully reset. You can now use your new password to sign in.
        </p>
        
        <Button
          onClick={goToLogin}
          className="w-full flex items-center justify-center gap-2"
        >
          Back to Login
        </Button>
      </div>
    </AuthLayout>
  );
};

export default ResetPassword;
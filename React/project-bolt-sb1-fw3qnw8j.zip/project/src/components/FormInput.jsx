import React, { useState } from 'react';
import { cn } from '../utils/cn';

const FormInput = ({
  name,
  label,
  value,
  onChange,
  error,
  icon,
  className,
  ...props
}) => {
  const [isFocused, setIsFocused] = useState(false);
  
  const handleFocus = () => setIsFocused(true);
  const handleBlur = () => setIsFocused(false);

  const isActive = isFocused || value;
  
  return (
    <div className="relative w-full">
      {label && (
        <label
          htmlFor={name}
          className={cn(
            "absolute left-3 transition-all duration-200",
            isActive 
              ? "transform -translate-y-6 scale-75 text-blue-600 font-medium origin-left" 
              : "top-1/2 -translate-y-1/2 text-gray-500",
            "pointer-events-none"
          )}
        >
          {label}
        </label>
      )}
      
      <div className={cn(
        "relative w-full",
        error ? "text-red-500" : "text-gray-900"
      )}>
        {icon && (
          <div className="absolute inset-y-0 left-3 flex items-center pointer-events-none">
            {icon}
          </div>
        )}
        
        <input
          id={name}
          name={name}
          value={value}
          onChange={onChange}
          onFocus={handleFocus}
          onBlur={handleBlur}
          className={cn(
            "w-full px-3 py-3 border rounded-lg transition-all duration-200",
            "focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500",
            icon ? "pl-10" : "pl-3",
            isActive ? "pt-6 pb-2" : "py-4",
            error 
              ? "border-red-300 focus:border-red-500 focus:ring-red-500" 
              : "border-gray-300",
            className
          )}
          {...props}
        />
      </div>
      
      {error && (
        <p className="mt-1 text-sm text-red-600">{error}</p>
      )}
    </div>
  );
};

export default FormInput;
import React from 'react';
import { Lock } from 'lucide-react';

const AuthLayout = ({ title, children }) => {
  return (
    <div className="min-h-screen w-full flex flex-col items-center justify-center px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-blue-50 to-indigo-50">
      <div className="w-full max-w-md">
        <div className="bg-white rounded-xl shadow-lg overflow-hidden transform transition-all hover:shadow-xl">
          <div className="p-8">
            <div className="flex flex-col items-center mb-8">
              <div className="w-12 h-12 rounded-full bg-blue-600 flex items-center justify-center mb-4">
                <Lock className="text-white" size={24} />
              </div>
              
              <h1 className="text-2xl font-semibold text-gray-900">{title}</h1>
            </div>
            
            {children}
          </div>
          
          <div className="px-8 py-4 bg-gray-50 border-t border-gray-100 flex justify-center">
            <p className="text-xs text-gray-500">
              © {new Date().getFullYear()} YourCompany. All rights reserved.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AuthLayout;